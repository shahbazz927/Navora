import React, { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import {
  Building2,
  MapPin,
  ExternalLink,
  ShieldCheck,
  CheckCircle,
  Bookmark,
  GitCompare,
  ArrowLeft,
  GraduationCap,
  IndianRupee,
  Calendar,
  Briefcase,
  Award,
  BookOpen,
  Home,
  CheckCircle2,
  AlertCircle,
  TrendingUp,
  Globe
} from 'lucide-react';
import { getInstitutionBySlug } from '../data/institutionsMaster';
import { useSavedColleges } from '../hooks/useSavedColleges';

export default function CollegeDetail() {
  const { slug } = useParams();
  const navigate = useNavigate();
  const { isSaved, toggleSaveCollege } = useSavedColleges();
  const [activeTab, setActiveTab] = useState('overview');

  const institution = getInstitutionBySlug(slug);

  if (!institution) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-white rounded-2xl p-8 border border-slate-200 text-center">
          <Building2 className="w-12 h-12 text-slate-300 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-slate-900 mb-2">Institution Not Found</h2>
          <p className="text-sm text-slate-500 mb-6">
            The college you are looking for is either not yet catalogued or the URL is incorrect.
          </p>
          <Link
            to="/colleges"
            className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-xl text-xs font-semibold hover:bg-blue-700"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to College Discovery</span>
          </Link>
        </div>
      </div>
    );
  }

  const saved = isSaved(institution.slug);

  const formatCurrency = (amt) => {
    if (!amt) return 'Not Available';
    return `₹${amt.toLocaleString('en-IN')}`;
  };

  const ugCourses = institution.courses?.filter((c) => c.level === 'UG') || [];
  const pgCourses = institution.courses?.filter((c) => c.level === 'PG' || c.level === 'Integrated') || [];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 pb-20">
      {/* Header Banner */}
      <div className="bg-[#0A192F] text-white border-b border-slate-800 pt-8 pb-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          {/* Breadcrumb & Back */}
          <div className="flex items-center justify-between mb-6">
            <Link
              to="/colleges"
              className="inline-flex items-center gap-2 text-xs font-semibold text-slate-400 hover:text-white transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Explore Colleges</span>
            </Link>

            <div className="flex items-center gap-2">
              <button
                onClick={() => toggleSaveCollege(institution.slug)}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                  saved
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                    : 'bg-white/5 text-slate-300 border-white/10 hover:bg-white/10'
                }`}
              >
                <Bookmark className={`w-3.5 h-3.5 ${saved ? 'fill-amber-400 text-amber-400' : ''}`} />
                <span>{saved ? 'Saved' : 'Save College'}</span>
              </button>

              <button
                onClick={() => navigate(`/colleges/compare?colleges=${institution.slug}`)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-white/5 text-slate-300 border border-white/10 hover:bg-white/10 transition-colors"
              >
                <GitCompare className="w-3.5 h-3.5" />
                <span>Compare</span>
              </button>
            </div>
          </div>

          {/* Title Area */}
          <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
            <div>
              <div className="flex flex-wrap items-center gap-2 mb-3">
                <span className="px-2.5 py-1 text-xs font-semibold rounded-md bg-blue-500/20 text-blue-300 border border-blue-400/30">
                  {institution.institutionType}
                </span>
                <span className="px-2 py-0.5 text-xs font-medium rounded-md bg-white/10 text-slate-300">
                  {institution.ownership}
                </span>
                {institution.establishedYear && (
                  <span className="px-2 py-0.5 text-xs font-medium rounded-md bg-white/10 text-slate-300">
                    Est. {institution.establishedYear}
                  </span>
                )}
                {institution.autonomousStatus && (
                  <span className="px-2 py-0.5 text-xs font-medium rounded-md bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    Autonomous
                  </span>
                )}
              </div>

              <h1 className="text-2xl sm:text-3xl md:text-4xl font-extrabold tracking-tight mb-2">
                {institution.name}
              </h1>

              <div className="flex items-center gap-2 text-sm text-slate-300 font-light">
                <MapPin className="w-4 h-4 text-slate-400 shrink-0" />
                <span>{institution.location || `${institution.city}, ${institution.state}`}</span>
              </div>
            </div>

            {/* Official Web Links */}
            <div className="flex flex-wrap md:flex-col items-start gap-2.5 shrink-0">
              {institution.website && (
                <a
                  href={institution.website}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-white text-slate-900 hover:bg-slate-100 transition-colors shadow-sm"
                >
                  <Globe className="w-3.5 h-3.5" />
                  <span>Official Website</span>
                  <ExternalLink className="w-3 h-3 text-slate-400" />
                </a>
              )}
              {institution.admissionUrl && (
                <a
                  href={institution.admissionUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-blue-600 text-white hover:bg-blue-500 transition-colors shadow-sm"
                >
                  <GraduationCap className="w-3.5 h-3.5" />
                  <span>Admissions Portal</span>
                  <ExternalLink className="w-3 h-3 text-blue-200" />
                </a>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Container */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 mt-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Details (2 Columns) */}
          <div className="lg:col-span-2 space-y-8">
            {/* Overview Card */}
            <section className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
              <h2 className="text-lg font-bold text-slate-900 mb-3 flex items-center gap-2">
                <Building2 className="w-5 h-5 text-blue-600" />
                <span>Institution Overview</span>
              </h2>
              <p className="text-sm text-slate-600 leading-relaxed mb-6 font-light">
                {institution.description || 'Information verified from official university records.'}
              </p>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 pt-4 border-t border-slate-100 text-xs">
                <div>
                  <span className="text-slate-400 block mb-0.5">Affiliation</span>
                  <span className="font-semibold text-slate-800">
                    {institution.universityAffiliation || 'Autonomous'}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block mb-0.5">Accreditation</span>
                  <span className="font-semibold text-slate-800">
                    {institution.accreditation || 'Recognized by UGC'}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block mb-0.5">NIRF / Category</span>
                  <span className="font-semibold text-slate-800">
                    {institution.nirfRank || 'State Accredited'}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block mb-0.5">Recognition</span>
                  <span className="font-semibold text-slate-800">
                    {institution.recognition || 'UGC / AICTE'}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block mb-0.5">Campus Living</span>
                  <span className="font-semibold text-slate-800">
                    {institution.hostelAvailable ? 'Hostels Available' : 'Day Scholar'}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block mb-0.5">City Zone</span>
                  <span className="font-semibold text-slate-800">{institution.city}</span>
                </div>
              </div>
            </section>

            {/* Courses & Fees Card */}
            <section className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
              <h2 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
                <GraduationCap className="w-5 h-5 text-blue-600" />
                <span>Courses & Fee Breakdown</span>
              </h2>

              <div className="space-y-6">
                {institution.courses && institution.courses.length > 0 ? (
                  institution.courses.map((course) => (
                    <div
                      key={course.id}
                      className="border border-slate-200 rounded-xl p-5 hover:border-blue-300 transition-colors bg-slate-50/50"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-0.5 text-xs font-bold bg-blue-100 text-blue-800 rounded">
                            {course.level}
                          </span>
                          <h3 className="text-base font-bold text-slate-900">
                            {course.degree} in {course.courseName}
                          </h3>
                        </div>
                        <span className="text-xs font-medium text-slate-500">
                          Duration: {course.duration}
                        </span>
                      </div>

                      {course.specialization && (
                        <p className="text-xs text-slate-600 mb-3">
                          <strong className="text-slate-700">Specialization:</strong>{' '}
                          {course.specialization}
                        </p>
                      )}

                      {/* Fees Grid */}
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-white p-3.5 rounded-lg border border-slate-200 text-xs mb-3">
                        <div>
                          <span className="text-slate-400 block text-[11px]">Tuition (Annual)</span>
                          <span className="font-bold text-slate-900">
                            {formatCurrency(course.tuitionFee)}
                          </span>
                        </div>
                        <div>
                          <span className="text-slate-400 block text-[11px]">Hostel (Annual)</span>
                          <span className="font-semibold text-slate-700">
                            {course.hostelFee ? formatCurrency(course.hostelFee) : 'Day Scholar'}
                          </span>
                        </div>
                        <div>
                          <span className="text-slate-400 block text-[11px]">Mess Charges</span>
                          <span className="font-semibold text-slate-700">
                            {course.messFee ? formatCurrency(course.messFee) : 'As per use'}
                          </span>
                        </div>
                        <div>
                          <span className="text-slate-400 block text-[11px]">Estimated Annual Cost</span>
                          <span className="font-bold text-blue-600">
                            {formatCurrency(course.totalAnnualFee || course.tuitionFee)}
                          </span>
                        </div>
                      </div>

                      {/* Admission & Eligibility */}
                      <div className="text-xs text-slate-600 space-y-1">
                        <p>
                          <strong className="text-slate-700">Eligibility:</strong> {course.eligibility}
                        </p>
                        <p>
                          <strong className="text-slate-700">Entrance Exam:</strong>{' '}
                          <span className="text-blue-700 font-semibold">{course.entranceExam}</span>
                        </p>
                        <p>
                          <strong className="text-slate-700">Admission Route:</strong>{' '}
                          {course.admissionMode}
                        </p>
                      </div>

                      {/* Provenance source link */}
                      {course.sourceUrl && (
                        <div className="mt-3 pt-2.5 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-500">
                          <span>
                            Academic Year: <strong>{course.academicYear}</strong> · Status:{' '}
                            <span className="text-emerald-700 font-medium capitalize">
                              {course.verificationStatus}
                            </span>
                          </span>
                          <a
                            href={course.sourceUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-blue-600 hover:underline inline-flex items-center gap-1 font-medium"
                          >
                            <span>View Source</span>
                            <ExternalLink className="w-3 h-3" />
                          </a>
                        </div>
                      )}
                    </div>
                  ))
                ) : (
                  <p className="text-xs text-slate-500 italic">
                    Official course and fee information not yet verified.
                  </p>
                )}
              </div>
            </section>

            {/* Placements Card */}
            {institution.placements && (
              <section className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-blue-600" />
                    <span>Verified Placement Statistics</span>
                  </h2>
                  <span className="text-xs text-slate-500 font-medium">
                    Batch Year: {institution.placements.placementYear}
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
                  <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-100 text-center">
                    <span className="text-xs text-slate-400 block mb-1">Median CTC</span>
                    <span className="text-base font-bold text-slate-900">
                      {formatCurrency(institution.placements.medianPackage)}
                    </span>
                  </div>
                  <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-100 text-center">
                    <span className="text-xs text-slate-400 block mb-1">Average CTC</span>
                    <span className="text-base font-bold text-slate-900">
                      {formatCurrency(institution.placements.averagePackage)}
                    </span>
                  </div>
                  <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-100 text-center">
                    <span className="text-xs text-slate-400 block mb-1">Highest Package</span>
                    <span className="text-base font-bold text-emerald-600">
                      {formatCurrency(institution.placements.highestPackage)}
                    </span>
                  </div>
                  <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-100 text-center">
                    <span className="text-xs text-slate-400 block mb-1">Placement Rate</span>
                    <span className="text-base font-bold text-blue-600">
                      {institution.placements.placementRate}%
                    </span>
                  </div>
                </div>

                {institution.placements.topRecruiters && (
                  <div>
                    <span className="text-xs font-bold text-slate-700 block mb-2">
                      Key Verified Employers
                    </span>
                    <div className="flex flex-wrap gap-2">
                      {institution.placements.topRecruiters.map((recruiter, i) => (
                        <span
                          key={i}
                          className="px-3 py-1 bg-slate-100 text-slate-800 rounded-lg text-xs font-medium"
                        >
                          {recruiter}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </section>
            )}

            {/* Campus Facilities */}
            {institution.facilities && institution.facilities.length > 0 && (
              <section className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
                <h2 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
                  <Home className="w-5 h-5 text-blue-600" />
                  <span>Campus Infrastructure & Facilities</span>
                </h2>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                  {institution.facilities.map((fac, i) => (
                    <div
                      key={i}
                      className="p-3 bg-slate-50 border border-slate-100 rounded-xl flex items-center gap-2 font-medium text-slate-800"
                    >
                      <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>{fac}</span>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* Scholarships Card */}
            {institution.scholarships && institution.scholarships.length > 0 && (
              <section className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
                <h2 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
                  <Award className="w-5 h-5 text-blue-600" />
                  <span>Scholarships & Financial Aid</span>
                </h2>
                <div className="space-y-3">
                  {institution.scholarships.map((sch, i) => (
                    <div
                      key={i}
                      className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-xs space-y-1"
                    >
                      <h4 className="font-bold text-slate-900 text-sm">{sch.name}</h4>
                      <p className="text-slate-600">
                        <strong className="text-slate-700">Eligibility:</strong> {sch.eligibility}
                      </p>
                      <p className="text-emerald-700 font-semibold">
                        <strong className="text-slate-700">Benefit:</strong> {sch.benefit}
                      </p>
                    </div>
                  ))}
                </div>
              </section>
            )}
          </div>

          {/* Right Sidebar: Data Verification & NAVORA Guidance */}
          <aside className="space-y-6">
            {/* Data Verification Card */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
              <div className="flex items-center gap-2 pb-3 border-b border-slate-100 mb-4">
                <ShieldCheck className="w-5 h-5 text-blue-600" />
                <h3 className="font-bold text-slate-900 text-sm">Data Verification</h3>
              </div>

              <div className="space-y-3 text-xs">
                <div>
                  <span className="text-slate-400 block text-[11px]">Academic Year</span>
                  <span className="font-bold text-slate-800">2026–27</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Annual Fee Basis</span>
                  <span className="font-bold text-slate-800">
                    {institution.minAnnualFee ? formatCurrency(institution.minAnnualFee) : 'Not Available'}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Source Provenance</span>
                  <span className="font-semibold text-slate-700">
                    NIRF, State Council (TSCHE / AFRC) & Official Institution
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Verification Status</span>
                  <span className="inline-flex items-center gap-1 text-emerald-700 font-bold">
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                    Verified Official
                  </span>
                </div>
              </div>

              {institution.website && (
                <div className="mt-4 pt-3 border-t border-slate-100">
                  <a
                    href={institution.website}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-2 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <span>View Official Source</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              )}
            </div>

            {/* NAVORA Career Pathway Card */}
            <div className="bg-gradient-to-br from-[#0A192F] to-slate-900 text-white rounded-2xl p-5 shadow-sm space-y-4">
              <div className="flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-blue-400" />
                <h3 className="font-bold text-sm">NAVORA Career Pathway</h3>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed font-light">
                Graduating from courses offered at {institution.shortName || institution.name} leads directly into recognized industry pathways:
              </p>

              <div className="space-y-2 text-xs">
                <div className="p-2.5 rounded-lg bg-white/10 border border-white/10">
                  <span className="font-bold block text-blue-300">Technology & Computing</span>
                  <span className="text-slate-300 text-[11px]">
                    Software Engineering → Cloud/AI Architecture → Product Leadership
                  </span>
                </div>
                <div className="p-2.5 rounded-lg bg-white/10 border border-white/10">
                  <span className="font-bold block text-blue-300">Management & Business</span>
                  <span className="text-slate-300 text-[11px]">
                    Analyst → Associate Consultant → Investment / Strategic Management
                  </span>
                </div>
              </div>

              <Link
                to="/advisor"
                className="w-full py-2.5 px-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
              >
                <span>Ask AI Advisor About This College</span>
              </Link>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}
